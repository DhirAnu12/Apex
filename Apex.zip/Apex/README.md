# Apex

Apex is a personal development app for planning your days, reflecting on progress, and getting AI-assisted coaching. It is built with Expo, React Native, and Expo Router.

## Run the app

Install dependencies and start Expo:

```bash
npm install
npx expo start
```

Use the Expo terminal menu to open the app in an iOS simulator, Android emulator, or Expo Go. To start a platform directly, run `npm run ios`, `npm run android`, or `npm run web`. Run `npm run lint` to check the code.

## Navigate Apex

The bottom tab bar stays available across the app. Choose a tab to open one of the five tools:

- **Chat**: Talk with the Apex mentor, start a new conversation, revisit chat history, and copy a response. Use the attachment control to select an image or take a photo.
- **Journal**: Write and save journal entries, save notes, then switch to Review to practice recalling saved notes with AI-generated questions and feedback.
- **Routine**: Generate a three-day routine informed by your profile and calendar, select a day, edit or remove tasks, and finalize the day's plan. Finalizing can schedule task reminders; notification permission is requested when the app starts.
- **Calendar**: Switch between weekly and monthly views, add or delete events, and select a day to manage its events. Calendar events can inform routine generation.
- **Performance**: Track today's routine checkpoints, record missed checkpoints, request an AI review, and look back at performance history.

On first launch, answer the onboarding questions to create the profile used to personalize routines and coaching. The app stores profile, chat, journal, calendar, routine, and performance data on the device using AsyncStorage. AI-assisted chat, journal review, and performance evaluation also send the relevant prompts and content to Anthropic and need an internet connection.

## Project layout

```text
app/                  Screens and navigation routes
  _layout.tsx         App startup, onboarding, and bottom tabs
  index.tsx           Chat
  journal.tsx         Journal and note review
  routine.tsx         Routine planning and reminders
  calendar.tsx        Calendar events
  performance.tsx     Checkpoints and performance history
assets/images/        App icon, splash screen, and platform icons
app.json              Expo app and platform configuration
eas.json              EAS Build profiles
package.json          Dependencies and development commands
```

Routes are file-based: the screens live in `app/`, and `_layout.tsx` registers them as tabs. Edit a screen in `app/` to change a tool; edit `app/_layout.tsx` to change onboarding or navigation. Platform icons and splash assets are configured in `app.json`.