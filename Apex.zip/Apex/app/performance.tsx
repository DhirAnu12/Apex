import AsyncStorage from "@react-native-async-storage/async-storage";
import { useEffect, useRef, useState } from "react";
import { Animated, ScrollView, Text, TouchableOpacity, View } from "react-native";

const parseTime = (timeStr: string) => {
  try {
    const cleaned = timeStr.split("-")[0].trim();
    const parts = cleaned.split(" ");
    const timePart = parts[0];
    const modifier = parts[1]?.toUpperCase();
    let [hours, minutes] = timePart.split(":").map(Number);
    if (!modifier) return null;
    if (modifier === "PM" && hours !== 12) hours += 12;
    if (modifier === "AM" && hours === 12) hours = 0;
    const date = new Date();
    date.setHours(hours, minutes, 0, 0);
    return date;
  } catch (e) {
    return null;
  }
};

const getStatus = (item: any, now: Date) => {
  if (item.status === "done") return "done";
  if (item.status === "failed") return "failed";
  const time = parseTime(item.time);
  if (!time) return "locked";
  const windowEnd = new Date(time.getTime() + 5 * 60 * 1000);
  if (now < time) return "locked";
  if (now >= time && now <= windowEnd) return "active";
  return "failed";
};

export default function Performance() {
  const [activeTab, setActiveTab] = useState<"today" | "history">("today");
  const [checkpoints, setCheckpoints] = useState<any[]>([]);
  const [score, setScore] = useState(0);
  const [holding, setHolding] = useState<string | null>(null);
  const [now, setNow] = useState(new Date());
  const [evaluation, setEvaluation] = useState("");
  const [evaluating, setEvaluating] = useState(false);
  const [userProfile, setUserProfile] = useState("");
  const [history, setHistory] = useState<any[]>([]);
  const [reviewBonus, setReviewBonus] = useState(0);
  const holdProgress = useRef(new Animated.Value(0)).current;
  const holdAnimation = useRef<any>(null);
  const checkpointsRef = useRef<any[]>([]);

  useEffect(() => {
    loadCheckpoints();
    loadHistory();
  }, []);

  useEffect(() => {
    checkpointsRef.current = checkpoints;
  }, [checkpoints]);

  useEffect(() => {
    const interval = setInterval(() => {
      setNow(new Date());
      autoFailExpired();
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const loadCheckpoints = async () => {
    try {
      const today = new Date().toDateString();
      const finalized3day = await AsyncStorage.getItem("finalized3day");
      const finalizedMap = finalized3day ? JSON.parse(finalized3day) : {};

      if (!finalizedMap[today]) {
        const routines3day = await AsyncStorage.getItem("routines3day");
        const routinesMap = routines3day ? JSON.parse(routines3day) : {};
        if (routinesMap[today]) {
          await AsyncStorage.setItem("dailyRoutine", JSON.stringify(routinesMap[today]));
          await AsyncStorage.setItem("routineFinalized", today);
          finalizedMap[today] = true;
          await AsyncStorage.setItem("finalized3day", JSON.stringify(finalizedMap));
        } else {
          setCheckpoints([]);
          setScore(0);
          return;
        }
      }

      const savedDate = await AsyncStorage.getItem("checkpointDate");
      const savedRoutine = await AsyncStorage.getItem("dailyRoutine");
      const savedCheckpoints = await AsyncStorage.getItem("checkpoints");
      const profile = await AsyncStorage.getItem("userProfile");
      if (profile) setUserProfile(profile);

      const spacedCards = await AsyncStorage.getItem("spacedCards");
      if (spacedCards) {
        const allCards = JSON.parse(spacedCards);
        const todayCards = allCards.filter((c: any) => {
          const reviewed = c.lastReviewed;
          return reviewed && new Date(reviewed).toDateString() === today;
        });
        const totalDue = allCards.filter((c: any) => new Date(c.nextReview) <= new Date()).length;
        if (totalDue > 0) {
          const bonus = Math.round((todayCards.length / totalDue) * 2);
          setReviewBonus(bonus);
        }
      }

      if (savedRoutine) {
        if (savedCheckpoints && savedDate === today) {
          const parsed = JSON.parse(savedCheckpoints);
          setCheckpoints(parsed);
          calculateScore(parsed);
        } else {
          const routine = JSON.parse(savedRoutine);
          const fresh = routine.map((item: any) => ({
            id: item.time + item.task,
            time: item.time,
            task: item.task,
            status: "pending"
          }));
          setCheckpoints(fresh);
          await AsyncStorage.setItem("checkpoints", JSON.stringify(fresh));
          await AsyncStorage.setItem("checkpointDate", today);
        }
      }
    } catch (e) {}
  };

  const loadHistory = async () => {
    try {
      const stored = await AsyncStorage.getItem("performanceHistory");
      if (stored) setHistory(JSON.parse(stored));
    } catch (e) {}
  };

  const autoFailExpired = async () => {
    const current = new Date();
    const current_checkpoints = checkpointsRef.current;
    if (!current_checkpoints.length) return;

    let changed = false;
    const updated = current_checkpoints.map((c: any) => {
      if (c.status !== "pending") return c;
      const time = parseTime(c.time);
      if (!time) return c;
      const windowEnd = new Date(time.getTime() + 5 * 60 * 1000);
      if (current > windowEnd) {
        changed = true;
        return { ...c, status: "failed" };
      }
      return c;
    });

    if (changed) {
      setCheckpoints(updated);
      calculateScore(updated);
      await AsyncStorage.setItem("checkpoints", JSON.stringify(updated));
    }
  };

  const calculateScore = (cps: any[]) => {
    const total = cps.length;
    if (total === 0) return;
    const completed = cps.filter(c => c.status === "done").length;
    const base = Math.round((completed / total) * 98);
    setScore(Math.min(100, base + reviewBonus));
  };

  const startHold = (id: string) => {
    setHolding(id);
    holdProgress.setValue(0);
    holdAnimation.current = Animated.timing(holdProgress, {
      toValue: 1,
      duration: 5000,
      useNativeDriver: false
    });
    holdAnimation.current.start(({ finished }: { finished: boolean }) => {
      if (finished) completeCheckpoint(id);
      setHolding(null);
      holdProgress.setValue(0);
    });
  };

  const cancelHold = () => {
    if (holdAnimation.current) holdAnimation.current.stop();
    setHolding(null);
    holdProgress.setValue(0);
  };

  const completeCheckpoint = async (id: string) => {
    const updated = checkpointsRef.current.map((c: any) =>
      c.id === id ? { ...c, status: "done" } : c
    );
    setCheckpoints(updated);
    calculateScore(updated);
    await AsyncStorage.setItem("checkpoints", JSON.stringify(updated));
  };

  const failCheckpoint = async (id: string) => {
    const updated = checkpointsRef.current.map((c: any) =>
      c.id === id ? { ...c, status: "failed" } : c
    );
    setCheckpoints(updated);
    calculateScore(updated);
    await AsyncStorage.setItem("checkpoints", JSON.stringify(updated));
  };

  const getEvaluation = async () => {
    setEvaluating(true);
    try {
      const completedCount = checkpoints.filter(c => c.status === "done").length;
      const failedCount = checkpoints.filter(c => c.status === "failed").length;
      const response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": "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",
          "anthropic-version": "2023-06-01",
          "anthropic-dangerous-direct-browser-access": "true"
        },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 300,
          system: `You are the user's personal AI companion. Evaluate their daily performance in 3-4 sentences max. Be direct and honest. Acknowledge wins, call out failures specifically, and give one clear focus for tomorrow. No essays. No questions.`,
          messages: [{
            role: "user",
            content: `Score: ${score}%\nCompleted: ${completedCount}\nFailed: ${failedCount}\n\nTasks:\n${checkpoints.map(c => `${c.time} - ${c.task}: ${c.status}`).join("\n")}\n\nProfile:\n${userProfile}\n\nGive me my end of day evaluation.`
          }]
        })
      });
      const data = await response.json();
      setEvaluation(data.content[0].text);

      const todayStr = new Date().toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" });
      const historyEntry = {
        date: todayStr,
        score,
        completed: completedCount,
        failed: failedCount,
        total: checkpoints.length
      };
      const stored = await AsyncStorage.getItem("performanceHistory");
      const existing = stored ? JSON.parse(stored) : [];
      const alreadyExists = existing.find((d: any) => d.date === todayStr);
      if (!alreadyExists) {
        const updated = [...existing, historyEntry];
        await AsyncStorage.setItem("performanceHistory", JSON.stringify(updated));
        setHistory(updated);
      }
    } catch (e) {}
    setEvaluating(false);
  };

  const scoreColor = (s?: number) => {
    const val = s !== undefined ? s : score;
    if (val >= 80) return "#22c55e";
    if (val >= 50) return "#f59e0b";
    return "#ff4444";
  };

  const completed = checkpoints.filter(c => c.status === "done").length;
  const failed = checkpoints.filter(c => c.status === "failed").length;
  const pending = checkpoints.filter(c => c.status === "pending").length;

  const avgScore = history.length > 0 ? Math.round(history.reduce((sum, d) => sum + d.score, 0) / history.length) : 0;
  const bestScore = history.length > 0 ? Math.max(...history.map(d => d.score)) : 0;
  const streak = (() => { let count = 0; for (const day of [...history].reverse()) { if (day.score >= 50) count++; else break; } return count; })();

  return (
    <View style={{ flex: 1, backgroundColor: "#0a0a0a" }}>
      <View style={{ padding: 20, paddingTop: 60, borderBottomColor: "#222", borderBottomWidth: 1 }}>
        <Text style={{ color: "#fff", fontSize: 18, fontWeight: "bold" }}>Performance</Text>
        <Text style={{ color: "#555", fontSize: 13, marginTop: 4 }}>
          {new Date().toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric" })}
        </Text>
      </View>

      <View style={{ flexDirection: "row", margin: 16, backgroundColor: "#111", borderRadius: 10, padding: 4 }}>
        <TouchableOpacity
          onPress={() => setActiveTab("today")}
          style={{ flex: 1, backgroundColor: activeTab === "today" ? "#4444ff" : "transparent", borderRadius: 8, padding: 10, alignItems: "center" }}
        >
          <Text style={{ color: activeTab === "today" ? "#fff" : "#555", fontWeight: "bold", fontSize: 13 }}>Today</Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => { setActiveTab("history"); loadHistory(); }}
          style={{ flex: 1, backgroundColor: activeTab === "history" ? "#4444ff" : "transparent", borderRadius: 8, padding: 10, alignItems: "center" }}
        >
          <Text style={{ color: activeTab === "history" ? "#fff" : "#555", fontWeight: "bold", fontSize: 13 }}>History</Text>
        </TouchableOpacity>
      </View>

      {activeTab === "today" && (
        <>
          {checkpoints.length === 0 ? (
            <View style={{ flex: 1, justifyContent: "center", alignItems: "center", padding: 32 }}>
              <Text style={{ color: "#555", fontSize: 15, textAlign: "center", lineHeight: 24 }}>
                No checkpoints yet.{"\n"}Finalize your routine first.
              </Text>
            </View>
          ) : (
            <ScrollView style={{ flex: 1 }}>
              <View style={{ margin: 20, backgroundColor: "#111", borderRadius: 16, padding: 20, borderWidth: 1, borderColor: "#222" }}>
                <Text style={{ color: "#555", fontSize: 13, marginBottom: 8 }}>TODAY'S SCORE</Text>
                <Text style={{ color: scoreColor(), fontSize: 48, fontWeight: "bold" }}>{score}%</Text>
                <View style={{ flexDirection: "row", gap: 16, marginTop: 12 }}>
                  <Text style={{ color: "#22c55e", fontSize: 13 }}>✓ {completed} done</Text>
                  <Text style={{ color: "#ff4444", fontSize: 13 }}>✕ {failed} failed</Text>
                  <Text style={{ color: "#555", fontSize: 13 }}>◯ {pending} pending</Text>
                </View>
                <View style={{ height: 6, backgroundColor: "#222", borderRadius: 3, marginTop: 16 }}>
                  <View style={{ height: 6, backgroundColor: scoreColor(), borderRadius: 3, width: `${score}%` as any }} />
                </View>
              </View>

              <View style={{ paddingHorizontal: 20 }}>
                {checkpoints.map((item) => {
                  const status = getStatus(item, now);
                  const time = parseTime(item.time);
                  const windowEnd = time ? new Date(time.getTime() + 5 * 60 * 1000) : null;
                  const minutesUntil = time ? Math.ceil((time.getTime() - now.getTime()) / 60000) : null;

                  return (
                    <View key={item.id} style={{
                      backgroundColor: "#111",
                      borderRadius: 12,
                      padding: 16,
                      marginBottom: 12,
                      borderWidth: 1,
                      borderColor: status === "done" ? "#22c55e" : status === "active" ? "#4444ff" : status === "failed" ? "#ff4444" : "#222",
                      opacity: status === "locked" ? 0.5 : 1
                    }}>
                      <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start" }}>
                        <View style={{ flex: 1 }}>
                          <Text style={{ color: "#555", fontSize: 12, marginBottom: 4 }}>{item.time}</Text>
                          <Text style={{ color: status === "done" ? "#555" : "#fff", fontSize: 15, textDecorationLine: status === "done" ? "line-through" : "none" }}>
                            {item.task}
                          </Text>
                          {status === "locked" && minutesUntil && minutesUntil > 0 && (
                            <Text style={{ color: "#555", fontSize: 11, marginTop: 4 }}>
                              🔒 Unlocks in {minutesUntil < 60 ? `${minutesUntil}m` : `${Math.ceil(minutesUntil / 60)}h`}
                            </Text>
                          )}
                          {status === "active" && windowEnd && (
                            <Text style={{ color: "#4444ff", fontSize: 11, marginTop: 4 }}>
                              ⚡ Active — window closes at {windowEnd.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                            </Text>
                          )}
                        </View>
                        <View style={{
                          width: 24,
                          height: 24,
                          borderRadius: 12,
                          backgroundColor: status === "done" ? "#22c55e" : status === "failed" ? "#ff4444" : status === "active" ? "#4444ff" : "#333",
                          borderWidth: 1,
                          borderColor: "#555",
                          justifyContent: "center",
                          alignItems: "center",
                          marginLeft: 12
                        }}>
                          {status === "done" && <Text style={{ color: "#fff", fontSize: 12 }}>✓</Text>}
                          {status === "failed" && <Text style={{ color: "#fff", fontSize: 12 }}>✕</Text>}
                          {status === "locked" && <Text style={{ color: "#555", fontSize: 10 }}>🔒</Text>}
                        </View>
                      </View>

                      {status === "active" && (
                        <View style={{ marginTop: 12, gap: 8 }}>
                          {holding === item.id && (
                            <View style={{ height: 4, backgroundColor: "#222", borderRadius: 2, overflow: "hidden" }}>
                              <Animated.View style={{
                                height: 4,
                                backgroundColor: "#22c55e",
                                borderRadius: 2,
                                width: holdProgress.interpolate({
                                  inputRange: [0, 1],
                                  outputRange: ["0%", "100%"]
                                })
                              }} />
                            </View>
                          )}
                          <View style={{ flexDirection: "row", gap: 8 }}>
                            <TouchableOpacity
                              onLongPress={() => completeCheckpoint(item.id)}
                              delayLongPress={5000}
                              onPressOut={cancelHold}
                              onPressIn={() => startHold(item.id)}
                              style={{
                                flex: 1,
                                backgroundColor: holding === item.id ? "#1a3a1a" : "#111",
                                borderWidth: 1,
                                borderColor: "#22c55e",
                                borderRadius: 8,
                                padding: 12,
                                alignItems: "center"
                              }}
                            >
                              <Text style={{ color: "#22c55e", fontSize: 13, fontWeight: "bold" }}>
                                {holding === item.id ? "Hold..." : "Hold 5s to Complete"}
                              </Text>
                            </TouchableOpacity>
                            <TouchableOpacity
                              onPress={() => failCheckpoint(item.id)}
                              style={{
                                backgroundColor: "#111",
                                borderWidth: 1,
                                borderColor: "#ff4444",
                                borderRadius: 8,
                                padding: 12,
                                paddingHorizontal: 16,
                                alignItems: "center"
                              }}
                            >
                              <Text style={{ color: "#ff4444", fontSize: 13 }}>Fail</Text>
                            </TouchableOpacity>
                          </View>
                        </View>
                      )}

                      {status === "locked" && (
                        <TouchableOpacity
                          onPress={() => failCheckpoint(item.id)}
                          style={{
                            marginTop: 10,
                            borderWidth: 1,
                            borderColor: "#ff4444",
                            borderRadius: 8,
                            padding: 10,
                            alignItems: "center"
                          }}
                        >
                          <Text style={{ color: "#ff4444", fontSize: 12 }}>Mark as Failed</Text>
                        </TouchableOpacity>
                      )}
                    </View>
                  );
                })}
              </View>

              <View style={{ margin: 20, marginTop: 8 }}>
                {!evaluation && (
                  <TouchableOpacity
                    onPress={getEvaluation}
                    disabled={evaluating}
                    style={{
                      backgroundColor: "#111",
                      borderWidth: 1,
                      borderColor: "#333",
                      borderRadius: 12,
                      padding: 16,
                      alignItems: "center",
                      marginBottom: 32
                    }}
                  >
                    <Text style={{ color: evaluating ? "#555" : "#fff", fontSize: 14 }}>
                      {evaluating ? "Evaluating..." : "Get End of Day Evaluation"}
                    </Text>
                  </TouchableOpacity>
                )}
                {evaluation !== "" && (
                  <View style={{
                    backgroundColor: "#111",
                    borderRadius: 12,
                    padding: 16,
                    borderWidth: 1,
                    borderColor: "#333",
                    marginBottom: 32
                  }}>
                    <Text style={{ color: "#555", fontSize: 12, marginBottom: 8 }}>END OF DAY</Text>
                    <Text style={{ color: "#fff", fontSize: 15, lineHeight: 22 }}>{evaluation}</Text>
                  </View>
                )}
              </View>
            </ScrollView>
          )}
        </>
      )}

      {activeTab === "history" && (
        <ScrollView style={{ flex: 1 }}>
          {history.length === 0 ? (
            <View style={{ justifyContent: "center", alignItems: "center", padding: 32, marginTop: 60 }}>
              <Text style={{ color: "#555", fontSize: 15, textAlign: "center", lineHeight: 24 }}>
                No history yet.{"\n"}Complete your first day to start tracking.
              </Text>
            </View>
          ) : (
            <>
              <View style={{ flexDirection: "row", padding: 20, gap: 12 }}>
                <View style={{ flex: 1, backgroundColor: "#111", borderRadius: 12, padding: 16, borderWidth: 1, borderColor: "#222" }}>
                  <Text style={{ color: "#555", fontSize: 11, marginBottom: 8 }}>AVERAGE</Text>
                  <Text style={{ color: scoreColor(avgScore), fontSize: 28, fontWeight: "bold" }}>{avgScore}%</Text>
                </View>
                <View style={{ flex: 1, backgroundColor: "#111", borderRadius: 12, padding: 16, borderWidth: 1, borderColor: "#222" }}>
                  <Text style={{ color: "#555", fontSize: 11, marginBottom: 8 }}>BEST</Text>
                  <Text style={{ color: "#22c55e", fontSize: 28, fontWeight: "bold" }}>{bestScore}%</Text>
                </View>
                <View style={{ flex: 1, backgroundColor: "#111", borderRadius: 12, padding: 16, borderWidth: 1, borderColor: "#222" }}>
                  <Text style={{ color: "#555", fontSize: 11, marginBottom: 8 }}>STREAK</Text>
                  <Text style={{ color: "#4444ff", fontSize: 28, fontWeight: "bold" }}>{streak}d</Text>
                </View>
              </View>

              <View style={{ paddingHorizontal: 20 }}>
                <Text style={{ color: "#555", fontSize: 13, marginBottom: 12 }}>DAILY LOG</Text>
                {[...history].reverse().map((day, index) => (
                  <View key={index} style={{
                    backgroundColor: "#111",
                    borderRadius: 12,
                    padding: 16,
                    marginBottom: 10,
                    borderWidth: 1,
                    borderColor: "#222",
                    flexDirection: "row",
                    justifyContent: "space-between",
                    alignItems: "center"
                  }}>
                    <View>
                      <Text style={{ color: "#fff", fontSize: 14, marginBottom: 4 }}>{day.date}</Text>
                      <Text style={{ color: "#555", fontSize: 12 }}>
                        {day.completed} done · {day.failed} failed · {day.total} total
                      </Text>
                    </View>
                    <Text style={{ color: scoreColor(day.score), fontSize: 24, fontWeight: "bold" }}>{day.score}%</Text>
                  </View>
                ))}
              </View>
            </>
          )}
        </ScrollView>
      )}
    </View>
  );
}