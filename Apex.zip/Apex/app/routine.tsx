import AsyncStorage from "@react-native-async-storage/async-storage";
import * as Notifications from "expo-notifications";
import { useEffect, useState } from "react";
import { ActivityIndicator, Modal, ScrollView, Text, TextInput, TouchableOpacity, View } from "react-native";

const parseRoutineTime = (timeStr: string) => {
  try {
    const cleaned = timeStr.split("-")[0].trim();
    const [timePart, modifier] = cleaned.split(" ");
    let [hours, minutes] = timePart.split(":").map(Number);
    if (!modifier) return null;
    if (modifier.toUpperCase() === "PM" && hours !== 12) hours += 12;
    if (modifier.toUpperCase() === "AM" && hours === 12) hours = 0;
    return { hours, minutes };
  } catch (e) {
    return null;
  }
};

const getDayLabel = (offset: number) => {
  const date = new Date();
  date.setDate(date.getDate() + offset);
  return date.toLocaleDateString("en-US", { weekday: "long", month: "short", day: "numeric" });
};

const getDayKey = (offset: number) => {
  const date = new Date();
  date.setDate(date.getDate() + offset);
  return date.toDateString();
};

const getDayOfWeek = (offset: number) => {
  const date = new Date();
  date.setDate(date.getDate() + offset);
  return date.toLocaleDateString("en-US", { weekday: "long" });
};

const toMins = (t: string) => {
  try {
    const [tp, mod] = t.split(" ");
    let [h, m] = tp.split(":").map(Number);
    if (mod === "PM" && h !== 12) h += 12;
    if (mod === "AM" && h === 12) h = 0;
    return h * 60 + m;
  } catch (e) {
    return 0;
  }
};

export default function Routine() {
  const [selectedDay, setSelectedDay] = useState(0);
  const [routines, setRoutines] = useState<any>({});
  const [finalized, setFinalized] = useState<any>({});
  const [loading, setLoading] = useState(false);
  const [userProfile, setUserProfile] = useState("");
  const [calendarEvents, setCalendarEvents] = useState<any[]>([]);
  const [editingIndex, setEditingIndex] = useState<number | null>(null);
  const [editText, setEditText] = useState("");
  const [editTime, setEditTime] = useState("");
  const [editHour, setEditHour] = useState("");
  const [editMinute, setEditMinute] = useState("");
  const [editAmPm, setEditAmPm] = useState("AM");

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const profile = await AsyncStorage.getItem("userProfile");
      if (profile) setUserProfile(profile);

      const events = await AsyncStorage.getItem("calendarEvents");
      if (events) setCalendarEvents(JSON.parse(events));

      const savedRoutines = await AsyncStorage.getItem("routines3day");
      if (savedRoutines) setRoutines(JSON.parse(savedRoutines));

      const savedFinalized = await AsyncStorage.getItem("finalized3day");
      if (savedFinalized) setFinalized(JSON.parse(savedFinalized));
    } catch (e) {}
  };

  const currentDayKey = getDayKey(selectedDay);
  const currentRoutine = routines[currentDayKey] || [];
  const isFinalized = finalized[currentDayKey] || false;
  const isGenerated = currentRoutine.length > 0;

  const generateRoutine = async () => {
    setLoading(true);
    const dayName = getDayOfWeek(selectedDay);
    const dayLabel = getDayLabel(selectedDay);
    const dayEvents = calendarEvents.filter(e => e.day === dayName);

    try {
      const response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": "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",
          "anthropic-version": "2023-06-01",
          "anthropic-dangerous-direct-browser-access": "true"
        },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1000,
          system: `You are a personal coach and mentor who creates daily routines. Generate a practical daily routine. Return ONLY a JSON array with no extra text, no markdown, no backticks. Each item must have: time (string like "6:00 AM"), task (string), and category (string: "health", "work", "learning", or "personal").`,
          messages: [{
            role: "user",
            content: `Generate my routine for ${dayLabel} based on my profile:\n\n${userProfile}\n\nFixed commitments for ${dayName}:\n${dayEvents.length > 0 ? dayEvents.map(e => `${e.time}: ${e.title}`).join("\n") : "None"}\n\nReturn only the JSON array.`
          }]
        })
      });

      const data = await response.json();
      const text = data.content[0].text.trim();
      const parsed = JSON.parse(text);
      const updated = { ...routines, [currentDayKey]: parsed };
      setRoutines(updated);
      await AsyncStorage.setItem("routines3day", JSON.stringify(updated));
    } catch (e) {
      console.log(e);
    }
    setLoading(false);
  };

  const finalizeDay = async () => {
    const updatedFinalized = { ...finalized, [currentDayKey]: true };
    setFinalized(updatedFinalized);
    await AsyncStorage.setItem("finalized3day", JSON.stringify(updatedFinalized));

    if (selectedDay === 0) {
      await AsyncStorage.setItem("dailyRoutine", JSON.stringify(currentRoutine));
      await AsyncStorage.setItem("routineFinalized", new Date().toDateString());
      await AsyncStorage.removeItem("checkpoints");
      await AsyncStorage.removeItem("checkpointDate");
    }

    await Notifications.cancelAllScheduledNotificationsAsync();
    await scheduleNotificationsForDay(currentRoutine, selectedDay);
    
  };

  const unfinalizeDay = async () => {
    const updatedFinalized = { ...finalized, [currentDayKey]: false };
    setFinalized(updatedFinalized);
    await AsyncStorage.setItem("finalized3day", JSON.stringify(updatedFinalized));
    if (selectedDay === 0) {
      await AsyncStorage.removeItem("routineFinalized");
      await AsyncStorage.removeItem("checkpoints");
      await AsyncStorage.removeItem("checkpointDate");
      await AsyncStorage.removeItem("dailyRoutine");
    }
  };

  const scheduleNotificationsForDay = async (routine: any[], dayOffset: number) => {
    const targetDate = new Date();
    targetDate.setDate(targetDate.getDate() + dayOffset);

    for (const item of routine) {
      const parsed = parseRoutineTime(item.time);
      if (!parsed) continue;
      const notifDate = new Date(targetDate);
      notifDate.setHours(parsed.hours, parsed.minutes, 0, 0);
      if (notifDate <= new Date()) continue;
      await Notifications.scheduleNotificationAsync({
        content: {
          title: "Routine Checkpoint",
          body: `${item.time} — ${item.task}. You have 5 minutes.`,
          sound: "default",
        },
        trigger: {
          type: Notifications.SchedulableTriggerInputTypes.DATE,
          date: notifDate,
        },
      });
    }
  };

  const saveEdit = async () => {
    if (editingIndex === null) return;
    if (!editHour || !editMinute || !editText.trim()) return;
    const minute = editMinute.padStart(2, "0");
    const builtTime = `${editHour}:${minute} ${editAmPm}`;

    let updated;
    if (editingIndex === -1) {
      const newItem = { time: builtTime, task: editText, category: "personal" };
      updated = [...currentRoutine, newItem];
      updated.sort((a: any, b: any) => toMins(a.time) - toMins(b.time));
    } else {
      updated = [...currentRoutine];
      updated[editingIndex] = { ...updated[editingIndex], task: editText, time: builtTime };
      updated.sort((a: any, b: any) => toMins(a.time) - toMins(b.time));
    }
    const updatedRoutines = { ...routines, [currentDayKey]: updated };
    setRoutines(updatedRoutines);
    setEditingIndex(null);
    await AsyncStorage.setItem("routines3day", JSON.stringify(updatedRoutines));
  };

  const deleteItem = async (index: number) => {
    const updated = currentRoutine.filter((_: any, i: number) => i !== index);
    const updatedRoutines = { ...routines, [currentDayKey]: updated };
    setRoutines(updatedRoutines);
    await AsyncStorage.setItem("routines3day", JSON.stringify(updatedRoutines));
  };

  const categoryColor = (cat: string) => {
    switch (cat) {
      case "health": return "#22c55e";
      case "work": return "#4444ff";
      case "learning": return "#f59e0b";
      case "personal": return "#ec4899";
      default: return "#555";
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: "#0a0a0a" }}>
      <View style={{ padding: 20, paddingTop: 60, borderBottomColor: "#222", borderBottomWidth: 1 }}>
        <Text style={{ color: "#fff", fontSize: 18, fontWeight: "bold" }}>Routine Planner</Text>
      </View>

      <View style={{ flexDirection: "row", padding: 16, gap: 8 }}>
        {[0, 1, 2].map(offset => (
          <TouchableOpacity
            key={offset}
            onPress={() => setSelectedDay(offset)}
            style={{
              flex: 1,
              backgroundColor: selectedDay === offset ? "#4444ff" : "#111",
              borderRadius: 10,
              padding: 10,
              alignItems: "center",
              borderWidth: 1,
              borderColor: selectedDay === offset ? "#4444ff" : "#333"
            }}
          >
            <Text style={{ color: selectedDay === offset ? "#fff" : "#555", fontSize: 11, marginBottom: 2 }}>
              {offset === 0 ? "TODAY" : offset === 1 ? "TOMORROW" : "DAY AFTER"}
            </Text>
            <Text style={{ color: selectedDay === offset ? "#fff" : "#777", fontSize: 12, fontWeight: "bold" }}>
              {getDayOfWeek(offset).slice(0, 3).toUpperCase()}
            </Text>
            {finalized[getDayKey(offset)] && (
              <Text style={{ color: "#22c55e", fontSize: 10, marginTop: 2 }}>✓</Text>
            )}
          </TouchableOpacity>
        ))}
      </View>

      <ScrollView style={{ flex: 1, paddingHorizontal: 20 }}>
        {!isGenerated && !loading && (
          <View style={{ alignItems: "center", marginTop: 60 }}>
            <Text style={{ color: "#555", fontSize: 15, textAlign: "center", marginBottom: 32, lineHeight: 24 }}>
              No routine for {getDayLabel(selectedDay)}.{"\n"}Let's build it.
            </Text>
            <TouchableOpacity
              onPress={generateRoutine}
              style={{ backgroundColor: "#4444ff", borderRadius: 12, paddingHorizontal: 32, paddingVertical: 16 }}
            >
              <Text style={{ color: "#fff", fontWeight: "bold", fontSize: 16 }}>Generate Routine</Text>
            </TouchableOpacity>
          </View>
        )}

        {loading && (
          <View style={{ alignItems: "center", marginTop: 60 }}>
            <ActivityIndicator size="large" color="#4444ff" />
            <Text style={{ color: "#555", marginTop: 16 }}>Building your day...</Text>
          </View>
        )}

        {isGenerated && !loading && (
          <>
            {isFinalized && (
              <Text style={{ color: "#22c55e", fontSize: 12, marginBottom: 12 }}>✓ Finalized</Text>
            )}

            {currentRoutine.map((item: any, index: number) => (
              <View key={index} style={{
                backgroundColor: "#111",
                borderRadius: 12,
                padding: 16,
                marginBottom: 12,
                borderWidth: 1,
                borderColor: "#222",
                flexDirection: "row",
                alignItems: "center"
              }}>
                <View style={{ width: 4, height: "100%", backgroundColor: categoryColor(item.category), borderRadius: 2, marginRight: 12 }} />
                <View style={{ flex: 1 }}>
                  <Text style={{ color: "#555", fontSize: 12, marginBottom: 4 }}>{item.time}</Text>
                  <Text style={{ color: "#fff", fontSize: 15 }}>{item.task}</Text>
                </View>
                {!isFinalized && (
                  <View style={{ flexDirection: "row", gap: 8 }}>
                    <TouchableOpacity
                      onPress={() => {
                        setEditingIndex(index);
                        setEditText(item.task);
                        setEditTime(item.time);
                        const parts = item.time.split(" ");
                        const timeParts = parts[0].split(":");
                        setEditHour(timeParts[0] || "");
                        setEditMinute(timeParts[1] || "");
                        setEditAmPm(parts[1] || "AM");
                      }}
                      style={{ padding: 6 }}
                    >
                      <Text style={{ color: "#4444ff", fontSize: 13 }}>Edit</Text>
                    </TouchableOpacity>
                    <TouchableOpacity onPress={() => deleteItem(index)} style={{ padding: 6 }}>
                      <Text style={{ color: "#ff4444", fontSize: 13 }}>✕</Text>
                    </TouchableOpacity>
                  </View>
                )}
              </View>
            ))}

            {!isFinalized && (
              <View style={{ gap: 12, marginTop: 8, marginBottom: 32 }}>
                <TouchableOpacity
                  onPress={() => { setEditingIndex(-1); setEditText(""); setEditTime(""); setEditHour(""); setEditMinute(""); setEditAmPm("AM"); }}
                  style={{ borderWidth: 1, borderColor: "#4444ff", borderRadius: 12, padding: 14, alignItems: "center" }}
                >
                  <Text style={{ color: "#4444ff", fontSize: 14 }}>+ Add Item</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={finalizeDay}
                  style={{ backgroundColor: "#22c55e", borderRadius: 12, padding: 16, alignItems: "center" }}
                >
                  <Text style={{ color: "#fff", fontWeight: "bold", fontSize: 16 }}>Finalize {getDayOfWeek(selectedDay)}</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={generateRoutine}
                  style={{ borderWidth: 1, borderColor: "#333", borderRadius: 12, padding: 16, alignItems: "center" }}
                >
                  <Text style={{ color: "#555", fontSize: 14 }}>Regenerate</Text>
                </TouchableOpacity>
              </View>
            )}

            {isFinalized && (
              <View style={{ gap: 12, marginTop: 8, marginBottom: 32 }}>
                <TouchableOpacity
                  onPress={unfinalizeDay}
                  style={{ borderWidth: 1, borderColor: "#f59e0b", borderRadius: 12, padding: 16, alignItems: "center" }}
                >
                  <Text style={{ color: "#f59e0b", fontSize: 14 }}>Unfinalize</Text>
                </TouchableOpacity>
              </View>
            )}
          </>
        )}
      </ScrollView>

      <Modal visible={editingIndex !== null} transparent animationType="fade">
        <View style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.8)", justifyContent: "center", padding: 24 }}>
          <View style={{ backgroundColor: "#111", borderRadius: 16, padding: 24, borderWidth: 1, borderColor: "#333" }}>
            <Text style={{ color: "#fff", fontWeight: "bold", fontSize: 16, marginBottom: 16 }}>
              {editingIndex === -1 ? "Add Item" : "Edit Item"}
            </Text>

            <Text style={{ color: "#555", fontSize: 12, marginBottom: 8 }}>TIME</Text>
            <View style={{ flexDirection: "row", gap: 8, marginBottom: 16 }}>
              <TextInput
                style={{ flex: 1, backgroundColor: "#0a0a0a", color: "#fff", borderRadius: 8, padding: 12, borderWidth: 1, borderColor: "#333", fontSize: 14, textAlign: "center" }}
                value={editHour}
                onChangeText={(v) => {
                  const num = parseInt(v);
                  if (v === "" || (num >= 1 && num <= 12)) setEditHour(v);
                }}
                placeholder="Hr"
                placeholderTextColor="#555"
                keyboardType="numeric"
                maxLength={2}
              />
              <Text style={{ color: "#555", fontSize: 20, alignSelf: "center" }}>:</Text>
              <TextInput
                style={{ flex: 1, backgroundColor: "#0a0a0a", color: "#fff", borderRadius: 8, padding: 12, borderWidth: 1, borderColor: "#333", fontSize: 14, textAlign: "center" }}
                value={editMinute}
                onChangeText={(v) => {
                  const num = parseInt(v);
                  if (v === "" || (num >= 0 && num <= 59)) setEditMinute(v);
                }}
                placeholder="Min"
                placeholderTextColor="#555"
                keyboardType="numeric"
                maxLength={2}
              />
              <View style={{ flexDirection: "row", borderRadius: 8, overflow: "hidden", borderWidth: 1, borderColor: "#333" }}>
                <TouchableOpacity
                  onPress={() => setEditAmPm("AM")}
                  style={{ paddingHorizontal: 14, paddingVertical: 12, backgroundColor: editAmPm === "AM" ? "#4444ff" : "#0a0a0a" }}
                >
                  <Text style={{ color: editAmPm === "AM" ? "#fff" : "#555", fontSize: 14 }}>AM</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={() => setEditAmPm("PM")}
                  style={{ paddingHorizontal: 14, paddingVertical: 12, backgroundColor: editAmPm === "PM" ? "#4444ff" : "#0a0a0a" }}
                >
                  <Text style={{ color: editAmPm === "PM" ? "#fff" : "#555", fontSize: 14 }}>PM</Text>
                </TouchableOpacity>
              </View>
            </View>

            <Text style={{ color: "#555", fontSize: 12, marginBottom: 8 }}>TASK</Text>
            <TextInput
              style={{ backgroundColor: "#0a0a0a", color: "#fff", borderRadius: 8, padding: 12, borderWidth: 1, borderColor: "#333", marginBottom: 16, fontSize: 14 }}
              value={editText}
              onChangeText={setEditText}
              placeholder="Task"
              placeholderTextColor="#555"
              multiline
            />
            <View style={{ flexDirection: "row", gap: 12 }}>
              <TouchableOpacity
                onPress={() => setEditingIndex(null)}
                style={{ flex: 1, borderWidth: 1, borderColor: "#333", borderRadius: 8, padding: 14, alignItems: "center" }}
              >
                <Text style={{ color: "#555" }}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={saveEdit}
                style={{ flex: 1, backgroundColor: "#4444ff", borderRadius: 8, padding: 14, alignItems: "center" }}
              >
                <Text style={{ color: "#fff", fontWeight: "bold" }}>Save</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}