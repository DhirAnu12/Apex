import AsyncStorage from "@react-native-async-storage/async-storage";
import { useEffect, useState } from "react";
import { Keyboard, KeyboardAvoidingView, ScrollView, Text, TextInput, TouchableOpacity, View } from "react-native";

export default function Journal() {
  const [activeTab, setActiveTab] = useState<"write" | "review">("write");
  const [entries, setEntries] = useState<any[]>([]);
  const [text, setText] = useState("");
  const [noteText, setNoteText] = useState("");
  const [reviewCards, setReviewCards] = useState<any[]>([]);
  const [currentCard, setCurrentCard] = useState(0);
  const [showAnswer, setShowAnswer] = useState(false);
  const [userAnswer, setUserAnswer] = useState("");
  const [feedback, setFeedback] = useState("");
  const [question, setQuestion] = useState("");
  const [generatingQuestion, setGeneratingQuestion] = useState(false);
  const [evaluating, setEvaluating] = useState(false);

  useEffect(() => {
    loadEntries();
    loadReviewCards();
  }, []);

  const loadEntries = async () => {
    try {
      const stored = await AsyncStorage.getItem("journalEntries");
      if (stored) setEntries(JSON.parse(stored));
    } catch (e) {}
  };

  const loadReviewCards = async () => {
    try {
      const stored = await AsyncStorage.getItem("spacedCards");
      if (!stored) return;
      const all = JSON.parse(stored);
      const today = new Date();
      const due = all.filter((c: any) => new Date(c.nextReview) <= today);
      setReviewCards(due);
    } catch (e) {}
  };

  const saveEntry = async () => {
    if (!text.trim()) return;
    const newEntry = {
      id: Date.now().toString(),
      text,
       date: new Date().toLocaleDateString("en-US", {
        weekday: "short",
        month: "short",
        day: "numeric"
      })
    };
    const updated = [newEntry, ...entries];
    setEntries(updated);
    setText("");
    Keyboard.dismiss();
    try {
      await AsyncStorage.setItem("journalEntries", JSON.stringify(updated));
    } catch (e) {}
  };

  const saveNote = async () => {
    if (!noteText.trim()) return;
    try {
      const stored = await AsyncStorage.getItem("spacedCards");
      const all = stored ? JSON.parse(stored) : [];
      const newCard = {
        id: Date.now().toString(),
        note: noteText,
        interval: 1,
        nextReview: new Date().toDateString(),
        createdAt: new Date().toLocaleDateString()
      };
      const updated = [...all, newCard];
      await AsyncStorage.setItem("spacedCards", JSON.stringify(updated));
      setNoteText("");
      Keyboard.dismiss();
      loadReviewCards();
    } catch (e) {}
  };

  const handleReview = async (remembered: boolean) => {
    try {
      const stored = await AsyncStorage.getItem("spacedCards");
      if (!stored) return;
      const all = JSON.parse(stored);
      const card = reviewCards[currentCard];
      const newInterval = remembered ? Math.min(card.interval * 2, 30) : 1;
      const nextReview = new Date();
      nextReview.setDate(nextReview.getDate() + newInterval);

      const updated = all.map((c: any) =>
        c.id === card.id
          ? { ...c, interval: newInterval, nextReview: nextReview.toDateString(), lastReviewed: new Date().toISOString() }
          : c
      );
      await AsyncStorage.setItem("spacedCards", JSON.stringify(updated));

      if (currentCard < reviewCards.length - 1) {
        setCurrentCard(currentCard + 1);
        setShowAnswer(false);
        setUserAnswer("");
        setFeedback("");
        setQuestion("");
      } else {
        setReviewCards([]);
        setCurrentCard(0);
        setShowAnswer(false);
        setUserAnswer("");
        setFeedback("");
        setQuestion("");
      }
    } catch (e) {}
  };

  const generateQuestion = async (note: string) => {
    setGeneratingQuestion(true);
    setQuestion("");
    setFeedback("");
    setUserAnswer("");
    try {
      const response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": "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",
          "anthropic-version": "2023-06-01",
          "anthropic-dangerous-direct-browser-access": "true"
        },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 100,
          system: "Generate a short quiz question based on the note. Just the question, nothing else. No preamble.",
          messages: [{ role: "user", content: `Note: ${note}\n\nGenerate a quiz question to test recall of this note.` }]
        })
      });
      const data = await response.json();
      setQuestion(data.content[0].text);
    } catch (e) {}
    setGeneratingQuestion(false);
  };

  const evaluateAnswer = async () => {
    if (!userAnswer.trim()) return;
    setEvaluating(true);
    try {
      const response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": "YOUR_API_KEY_HERE",
          "anthropic-version": "2023-06-01",
          "anthropic-dangerous-direct-browser-access": "true"
        },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 150,
          system: "Evaluate if the user's answer is correct based on the original note. Be lenient — if the core concept is right, it counts. Reply with: CORRECT or INCORRECT on the first line, then one sentence of feedback.",
          messages: [{ role: "user", content: `Original note: ${reviewCards[currentCard]?.note}\n\nQuestion: ${question}\n\nUser's answer: ${userAnswer}` }]
        })
      });
      const data = await response.json();
      const result = data.content[0].text;
      const remembered = result.startsWith("CORRECT");
      setFeedback(result);
      setShowAnswer(true);
      setTimeout(() => handleReview(remembered), 2000);
    } catch (e) {}
    setEvaluating(false);
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1, backgroundColor: "#0a0a0a" }} behavior="padding" keyboardVerticalOffset={0}>
      <View style={{ padding: 20, paddingTop: 60, borderBottomColor: "#222", borderBottomWidth: 1 }}>
        <Text style={{ color: "#fff", fontSize: 18, fontWeight: "bold" }}>Journal</Text>
      </View>

      <View style={{ flexDirection: "row", margin: 16, backgroundColor: "#111", borderRadius: 10, padding: 4 }}>
        <TouchableOpacity
          onPress={() => setActiveTab("write")}
          style={{ flex: 1, backgroundColor: activeTab === "write" ? "#4444ff" : "transparent", borderRadius: 8, padding: 10, alignItems: "center" }}
        >
          <Text style={{ color: activeTab === "write" ? "#fff" : "#555", fontWeight: "bold", fontSize: 13 }}>Write</Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => { setActiveTab("review"); loadReviewCards(); }}
          style={{ flex: 1, backgroundColor: activeTab === "review" ? "#4444ff" : "transparent", borderRadius: 8, padding: 10, alignItems: "center" }}
        >
          <Text style={{ color: activeTab === "review" ? "#fff" : "#555", fontWeight: "bold", fontSize: 13 }}>
            Review {reviewCards.length > 0 ? `(${reviewCards.length})` : ""}
          </Text>
        </TouchableOpacity>
      </View>

      {activeTab === "write" && (
        <ScrollView style={{ flex: 1, paddingHorizontal: 20 }} keyboardShouldPersistTaps="handled" onScrollBeginDrag={Keyboard.dismiss} contentContainerStyle={{ paddingBottom: 300 }}>
          <TextInput
            style={{
              backgroundColor: "#111",
              color: "#fff",
              borderRadius: 12,
              padding: 16,
              fontSize: 15,
              borderWidth: 1,
              borderColor: "#333",
              minHeight: 120,
              textAlignVertical: "top",
              marginBottom: 12
            }}
            value={text}
            onChangeText={setText}
            placeholder="What happened today? What did you learn? What did you avoid?"
            placeholderTextColor="#555"
            multiline
          />

          

          <TouchableOpacity
            onPress={saveEntry}
            style={{
              backgroundColor: "#4444ff",
              borderRadius: 12,
              padding: 16,
              alignItems: "center",
              marginBottom: 24
            }}
          >
            <Text style={{ color: "#fff", fontWeight: "bold", fontSize: 16 }}>Save Entry</Text>
          </TouchableOpacity>

          <View style={{ backgroundColor: "#111", borderRadius: 12, padding: 16, marginBottom: 24, borderWidth: 1, borderColor: "#333" }}>
            <Text style={{ color: "#fff", fontWeight: "bold", fontSize: 14, marginBottom: 8 }}>📌 Save something to remember</Text>
            <Text style={{ color: "#555", fontSize: 12, marginBottom: 12 }}>This will be reviewed using spaced repetition</Text>
            <TextInput
              style={{
                backgroundColor: "#0a0a0a",
                color: "#fff",
                borderRadius: 8,
                padding: 12,
                fontSize: 14,
                borderWidth: 1,
                borderColor: "#333",
                marginBottom: 10,
                minHeight: 80,
                textAlignVertical: "top"
              }}
              value={noteText}
              onChangeText={setNoteText}
              placeholder="e.g. The formula for compound interest is A = P(1 + r/n)^nt"
              placeholderTextColor="#555"
              multiline
            />
            <TouchableOpacity
              onPress={saveNote}
              style={{ backgroundColor: "#1a1a2e", borderWidth: 1, borderColor: "#4444ff", borderRadius: 8, padding: 12, alignItems: "center" }}
            >
              <Text style={{ color: "#4444ff", fontWeight: "bold" }}>Save Note</Text>
            </TouchableOpacity>
          </View>

          {entries.map((entry) => (
            <View key={entry.id} style={{
              backgroundColor: "#111",
              borderRadius: 12,
              padding: 16,
              marginBottom: 12,
              borderWidth: 1,
              borderColor: "#222"
            }}>
              <View style={{ flexDirection: "row", justifyContent: "space-between", marginBottom: 8 }}>
                <Text style={{ color: "#4444ff", fontSize: 13, fontWeight: "bold" }}>{entry.date}</Text>
                {entry.mood ? <Text style={{ color: "#555", fontSize: 13 }}>{entry.mood}</Text> : null}
              </View>
              <Text style={{ color: "#ccc", fontSize: 15, lineHeight: 22 }}>{entry.text}</Text>
            </View>
          ))}
        </ScrollView>
      )}

      {activeTab === "review" && (
        <View style={{ flex: 1, padding: 20 }}>
          {reviewCards.length === 0 ? (
            <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
              <Text style={{ color: "#22c55e", fontSize: 18, fontWeight: "bold", marginBottom: 12 }}>All caught up</Text>
              <Text style={{ color: "#555", fontSize: 14, textAlign: "center", lineHeight: 22 }}>
                No notes due for review.{"\n"}Save something to remember in the Write tab.
              </Text>
            </View>
          ) : (
            <View style={{ flex: 1 }}>
              <Text style={{ color: "#555", fontSize: 13, marginBottom: 16 }}>
                {currentCard + 1} of {reviewCards.length} due today
              </Text>

              <View style={{ flex: 1, backgroundColor: "#111", borderRadius: 16, padding: 24, borderWidth: 1, borderColor: "#333" }}>
                {!question && !generatingQuestion && (
                  <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
                    <TouchableOpacity
                      onPress={() => generateQuestion(reviewCards[currentCard]?.note)}
                      style={{ backgroundColor: "#4444ff", borderRadius: 12, padding: 16, paddingHorizontal: 32 }}
                    >
                      <Text style={{ color: "#fff", fontWeight: "bold", fontSize: 15 }}>Start Review</Text>
                    </TouchableOpacity>
                  </View>
                )}

                {generatingQuestion && (
                  <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
                    <Text style={{ color: "#555" }}>Generating question...</Text>
                  </View>
                )}

                {question !== "" && !generatingQuestion && (
                  <View style={{ flex: 1 }}>
                    <Text style={{ color: "#555", fontSize: 12, marginBottom: 12 }}>QUESTION</Text>
                    <Text style={{ color: "#fff", fontSize: 17, lineHeight: 26, marginBottom: 24 }}>{question}</Text>

                    {!showAnswer && (
                      <>
                        <TextInput
                          style={{
                            backgroundColor: "#0a0a0a",
                            color: "#fff",
                            borderRadius: 10,
                            padding: 14,
                            fontSize: 15,
                            borderWidth: 1,
                            borderColor: "#333",
                            minHeight: 80,
                            textAlignVertical: "top",
                            marginBottom: 12
                          }}
                          value={userAnswer}
                          onChangeText={setUserAnswer}
                          placeholder="Type your answer..."
                          placeholderTextColor="#555"
                          multiline
                        />
                        <TouchableOpacity
                          onPress={evaluateAnswer}
                          disabled={evaluating || !userAnswer.trim()}
                          style={{
                            backgroundColor: evaluating ? "#333" : "#4444ff",
                            borderRadius: 10,
                            padding: 14,
                            alignItems: "center"
                          }}
                        >
                          <Text style={{ color: "#fff", fontWeight: "bold" }}>
                            {evaluating ? "Evaluating..." : "Submit Answer"}
                          </Text>
                        </TouchableOpacity>
                      </>
                    )}

                    {feedback !== "" && (
                      <View style={{
                        marginTop: 16,
                        backgroundColor: feedback.startsWith("CORRECT") ? "#001a00" : "#1a0000",
                        borderRadius: 10,
                        padding: 14,
                        borderWidth: 1,
                        borderColor: feedback.startsWith("CORRECT") ? "#22c55e" : "#ff4444"
                      }}>
                        <Text style={{ color: feedback.startsWith("CORRECT") ? "#22c55e" : "#ff4444", fontWeight: "bold", marginBottom: 4 }}>
                          {feedback.startsWith("CORRECT") ? "✓ Correct" : "✕ Incorrect"}
                        </Text>
                        <Text style={{ color: "#ccc", fontSize: 13, lineHeight: 20 }}>
                          {feedback.split("\n").slice(1).join(" ")}
                        </Text>
                      </View>
                    )}
                  </View>
                )}
              </View>

              <Text style={{ color: "#555", fontSize: 11, textAlign: "center", marginTop: 12 }}>
                Saved on {reviewCards[currentCard]?.createdAt}
              </Text>
            </View>
          )}
        </View>
      )}
    </KeyboardAvoidingView>
  );
}