import AsyncStorage from "@react-native-async-storage/async-storage";
import { useEffect, useState } from "react";
import { Keyboard, KeyboardAvoidingView, Modal, ScrollView, Text, TextInput, TouchableOpacity, View } from "react-native";

const DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
const MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
const WEEKDAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

export default function Calendar() {
  const [view, setView] = useState<"weekly" | "monthly">("weekly");
  const [events, setEvents] = useState<any[]>([]);
  const [title, setTitle] = useState("");
  const [time, setTime] = useState("");
  const [day, setDay] = useState("Monday");
  const [showForm, setShowForm] = useState(false);
  const [selectedDate, setSelectedDate] = useState<number | null>(null);
  const [currentMonth, setCurrentMonth] = useState(new Date().getMonth());
  const [currentYear, setCurrentYear] = useState(new Date().getFullYear());
  const [showDayModal, setShowDayModal] = useState(false);
  const [modalTitle, setModalTitle] = useState("");
  const [modalTime, setModalTime] = useState("");

  useEffect(() => {
    loadEvents();
  });

  const loadEvents = async () => {
    try {
      const stored = await AsyncStorage.getItem("calendarEvents");
      if (stored) setEvents(JSON.parse(stored));
    } catch (e) {}
  };

  const saveEvent = async () => {
    if (!title.trim() || !time.trim()) return;
    const newEvent = {
      id: Date.now().toString(),
      title,
      time,
      day,
      type: "weekly"
    };
    const updated = [...events, newEvent];
    setEvents(updated);
    setTitle("");
    setTime("");
    setDay("Monday");
    setShowForm(false);
    Keyboard.dismiss();
    try {
      await AsyncStorage.setItem("calendarEvents", JSON.stringify(updated));
    } catch (e) {}
  };

  const saveMonthlyEvent = async () => {
    if (!modalTitle.trim() || !selectedDate === null) return;
    const newEvent = {
      id: Date.now().toString(),
      title: modalTitle,
      time: modalTime,
      date: selectedDate,
      month: MONTHS[currentMonth],
      year: currentYear,
      type: "monthly"
    };
    const updated = [...events, newEvent];
    setEvents(updated);
    setModalTitle("");
    setModalTime("");
    setShowDayModal(false);
    try {
      await AsyncStorage.setItem("calendarEvents", JSON.stringify(updated));
    } catch (e) {}
  };

  const deleteEvent = async (id: string) => {
    const updated = events.filter(e => e.id !== id);
    setEvents(updated);
    try {
      await AsyncStorage.setItem("calendarEvents", JSON.stringify(updated));
    } catch (e) {}
  };

  const getDaysInMonth = (month: number, year: number) => {
    return new Date(year, month + 1, 0).getDate();
  };

  const getFirstDayOfMonth = (month: number, year: number) => {
    return new Date(year, month, 1).getDay();
  };

  const weeklyEvents = events.filter(e => e.type === "weekly" || !e.type);
  const monthlyEvents = events.filter(e => e.type === "monthly");

  const eventsByDay = DAYS.map(d => ({
    day: d,
    events: weeklyEvents.filter(e => e.day === d)
  })).filter(d => d.events.length > 0);

  const getEventsForDate = (date: number) => {
    return monthlyEvents.filter(e =>
      e.date === date &&
      e.month === MONTHS[currentMonth] &&
      e.year === currentYear
    );
  };

  const daysInMonth = getDaysInMonth(currentMonth, currentYear);
  const firstDay = getFirstDayOfMonth(currentMonth, currentYear);
  const today = new Date();

  const renderCalendarGrid = () => {
    const totalCells = Math.ceil((firstDay + daysInMonth) / 7) * 7;
    const rows = [];
    let cells = [];

    for (let i = 0; i < totalCells; i++) {
      const dayNum = i - firstDay + 1;
      const isValid = dayNum >= 1 && dayNum <= daysInMonth;
      const isToday = isValid && dayNum === today.getDate() && currentMonth === today.getMonth() && currentYear === today.getFullYear();
      const isSelected = isValid && selectedDate === dayNum;
      const dayEvents = isValid ? getEventsForDate(dayNum) : [];

      cells.push(
        <TouchableOpacity
          key={i}
          onPress={() => { if (isValid) { setSelectedDate(dayNum); setShowDayModal(true); } }}
          style={{ flex: 1, alignItems: "center", paddingVertical: 8 }}
        >
          <View style={{
            width: 36,
            height: 36,
            borderRadius: 18,
            backgroundColor: isToday ? "#ff3b30" : isSelected ? "#4444ff" : "transparent",
            alignItems: "center",
            justifyContent: "center"
          }}>
            <Text style={{
              color: isValid ? "#fff" : "transparent",
              fontSize: 15,
              fontWeight: isToday ? "bold" : "normal"
            }}>
              {isValid ? dayNum : ""}
            </Text>
          </View>
          {dayEvents.length > 0 && (
            <View style={{ width: 4, height: 4, borderRadius: 2, backgroundColor: isToday ? "#fff" : "#4444ff", marginTop: 2 }} />
          )}
        </TouchableOpacity>
      );

      if ((i + 1) % 7 === 0) {
        rows.push(
          <View key={`row-${i}`} style={{ flexDirection: "row", borderBottomWidth: 1, borderBottomColor: "#1a1a1a" }}>
            {cells}
          </View>
        );
        cells = [];
      }
    }
    return rows;
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1, backgroundColor: "#0a0a0a" }} behavior="padding" keyboardVerticalOffset={0}>
      <View style={{ padding: 20, paddingTop: 60, borderBottomColor: "#222", borderBottomWidth: 1, flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}>
        <Text style={{ color: "#fff", fontSize: 18, fontWeight: "bold" }}>Calendar</Text>
        {view === "weekly" && (
          <TouchableOpacity
            onPress={() => setShowForm(!showForm)}
            style={{ backgroundColor: "#4444ff", borderRadius: 8, paddingHorizontal: 14, paddingVertical: 8 }}
          >
            <Text style={{ color: "#fff", fontWeight: "bold" }}>{showForm ? "Cancel" : "+ Add"}</Text>
          </TouchableOpacity>
        )}
      </View>

      <View style={{ flexDirection: "row", margin: 16, backgroundColor: "#111", borderRadius: 10, padding: 4 }}>
        <TouchableOpacity
          onPress={() => setView("weekly")}
          style={{ flex: 1, backgroundColor: view === "weekly" ? "#4444ff" : "transparent", borderRadius: 8, padding: 10, alignItems: "center" }}
        >
          <Text style={{ color: view === "weekly" ? "#fff" : "#555", fontWeight: "bold", fontSize: 13 }}>Weekly</Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => setView("monthly")}
          style={{ flex: 1, backgroundColor: view === "monthly" ? "#4444ff" : "transparent", borderRadius: 8, padding: 10, alignItems: "center" }}
        >
          <Text style={{ color: view === "monthly" ? "#fff" : "#555", fontWeight: "bold", fontSize: 13 }}>Monthly</Text>
        </TouchableOpacity>
      </View>

      <ScrollView style={{ flex: 1, paddingHorizontal: 20 }} keyboardShouldPersistTaps="handled" onScrollBeginDrag={Keyboard.dismiss}>

        {view === "weekly" && (
          <>
            {showForm && (
              <View style={{ backgroundColor: "#111", borderRadius: 12, padding: 16, marginBottom: 20, borderWidth: 1, borderColor: "#333" }}>
                <Text style={{ color: "#fff", fontWeight: "bold", marginBottom: 12, fontSize: 15 }}>New Weekly Event</Text>
                <TextInput
                  style={{ backgroundColor: "#0a0a0a", color: "#fff", borderRadius: 8, padding: 12, borderWidth: 1, borderColor: "#333", marginBottom: 10, fontSize: 14 }}
                  value={title}
                  onChangeText={setTitle}
                  placeholder="Event name"
                  placeholderTextColor="#555"
                />
                <TextInput
                  style={{ backgroundColor: "#0a0a0a", color: "#fff", borderRadius: 8, padding: 12, borderWidth: 1, borderColor: "#333", marginBottom: 10, fontSize: 14 }}
                  value={time}
                  onChangeText={setTime}
                  placeholder="Time (e.g. 10:00 AM - 12:00 PM)"
                  placeholderTextColor="#555"
                />
                <Text style={{ color: "#555", fontSize: 13, marginBottom: 8 }}>Day of week:</Text>
                <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 12 }}>
                  {DAYS.map(d => (
                    <TouchableOpacity
                      key={d}
                      onPress={() => setDay(d)}
                      style={{
                        backgroundColor: day === d ? "#4444ff" : "#0a0a0a",
                        borderRadius: 8,
                        paddingHorizontal: 12,
                        paddingVertical: 8,
                        marginRight: 8,
                        borderWidth: 1,
                        borderColor: day === d ? "#4444ff" : "#333"
                      }}
                    >
                      <Text style={{ color: day === d ? "#fff" : "#555", fontSize: 13 }}>{d.slice(0, 3)}</Text>
                    </TouchableOpacity>
                  ))}
                </ScrollView>
                <TouchableOpacity
                  onPress={saveEvent}
                  style={{ backgroundColor: "#4444ff", borderRadius: 8, padding: 14, alignItems: "center" }}
                >
                  <Text style={{ color: "#fff", fontWeight: "bold" }}>Save Event</Text>
                </TouchableOpacity>
              </View>
            )}

            {eventsByDay.length === 0 && !showForm && (
              <View style={{ alignItems: "center", marginTop: 60 }}>
                <Text style={{ color: "#555", fontSize: 15, textAlign: "center", lineHeight: 24 }}>
                  No weekly events yet.{"\n"}Add your classes and commitments.
                </Text>
              </View>
            )}

            {eventsByDay.map(({ day: d, events: dayEvents }) => (
              <View key={d} style={{ marginBottom: 24 }}>
                <Text style={{ color: "#4444ff", fontSize: 13, fontWeight: "bold", marginBottom: 10, letterSpacing: 1 }}>
                  {d.toUpperCase()}
                </Text>
                {dayEvents.map(event => (
                  <View key={event.id} style={{
                    backgroundColor: "#111",
                    borderRadius: 12,
                    padding: 14,
                    marginBottom: 8,
                    borderWidth: 1,
                    borderColor: "#222",
                    flexDirection: "row",
                    justifyContent: "space-between",
                    alignItems: "center"
                  }}>
                    <View>
                      <Text style={{ color: "#fff", fontSize: 15, marginBottom: 4 }}>{event.title}</Text>
                      <Text style={{ color: "#555", fontSize: 13 }}>{event.time}</Text>
                    </View>
                    <TouchableOpacity onPress={() => deleteEvent(event.id)}>
                      <Text style={{ color: "#ff4444", fontSize: 20 }}>×</Text>
                    </TouchableOpacity>
                  </View>
                ))}
              </View>
            ))}
          </>
        )}

        {view === "monthly" && (
          <>
            <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
              <TouchableOpacity onPress={() => {
                if (currentMonth === 0) { setCurrentMonth(11); setCurrentYear(currentYear - 1); }
                else setCurrentMonth(currentMonth - 1);
              }}>
                <Text style={{ color: "#4444ff", fontSize: 20 }}>‹</Text>
              </TouchableOpacity>
              <Text style={{ color: "#fff", fontSize: 16, fontWeight: "bold" }}>
                {MONTHS[currentMonth]} {currentYear}
              </Text>
              <TouchableOpacity onPress={() => {
                if (currentMonth === 11) { setCurrentMonth(0); setCurrentYear(currentYear + 1); }
                else setCurrentMonth(currentMonth + 1);
              }}>
                <Text style={{ color: "#4444ff", fontSize: 20 }}>›</Text>
              </TouchableOpacity>
            </View>

            <View style={{ flexDirection: "row", marginBottom: 8 }}>
              {WEEKDAYS.map(wd => (
                <View key={wd} style={{ flex: 1, alignItems: "center" }}>
                  <Text style={{ color: "#555", fontSize: 11 }}>{wd}</Text>
                </View>
              ))}
            </View>

            <View style={{ marginBottom: 24 }}>
              {renderCalendarGrid()}
            </View>

            {selectedDate && (
              <View style={{ marginBottom: 24 }}>
                <Text style={{ color: "#4444ff", fontSize: 13, fontWeight: "bold", marginBottom: 10 }}>
                  {MONTHS[currentMonth].toUpperCase()} {selectedDate}
                </Text>
                {getEventsForDate(selectedDate).length === 0 ? (
                  <Text style={{ color: "#555", fontSize: 13 }}>No events. Tap the date to add one.</Text>
                ) : (
                  getEventsForDate(selectedDate).map(event => (
                    <View key={event.id} style={{
                      backgroundColor: "#111",
                      borderRadius: 12,
                      padding: 14,
                      marginBottom: 8,
                      borderWidth: 1,
                      borderColor: "#222",
                      flexDirection: "row",
                      justifyContent: "space-between",
                      alignItems: "center"
                    }}>
                      <View>
                        <Text style={{ color: "#fff", fontSize: 15, marginBottom: 4 }}>{event.title}</Text>
                        {event.time ? <Text style={{ color: "#555", fontSize: 13 }}>{event.time}</Text> : null}
                      </View>
                      <TouchableOpacity onPress={() => deleteEvent(event.id)}>
                        <Text style={{ color: "#ff4444", fontSize: 20 }}>×</Text>
                      </TouchableOpacity>
                    </View>
                  ))
                )}
              </View>
            )}
          </>
        )}
      </ScrollView>

      <Modal visible={showDayModal} transparent animationType="slide">
        <View style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.8)", justifyContent: "flex-end" }}>
          <View style={{ backgroundColor: "#111", borderTopLeftRadius: 20, borderTopRightRadius: 20, padding: 24, borderWidth: 1, borderColor: "#333" }}>
            <Text style={{ color: "#fff", fontWeight: "bold", fontSize: 16, marginBottom: 4 }}>
              {MONTHS[currentMonth]} {selectedDate}
            </Text>
            <Text style={{ color: "#555", fontSize: 13, marginBottom: 16 }}>Add an event to this day</Text>
            <TextInput
              style={{ backgroundColor: "#0a0a0a", color: "#fff", borderRadius: 8, padding: 12, borderWidth: 1, borderColor: "#333", marginBottom: 10, fontSize: 14 }}
              value={modalTitle}
              onChangeText={setModalTitle}
              placeholder="Event name"
              placeholderTextColor="#555"
            />
            <TextInput
              style={{ backgroundColor: "#0a0a0a", color: "#fff", borderRadius: 8, padding: 12, borderWidth: 1, borderColor: "#333", marginBottom: 16, fontSize: 14 }}
              value={modalTime}
              onChangeText={setModalTime}
              placeholder="Time (optional)"
              placeholderTextColor="#555"
            />
            <View style={{ flexDirection: "row", gap: 12 }}>
              <TouchableOpacity
                onPress={() => { setShowDayModal(false); setModalTitle(""); setModalTime(""); }}
                style={{ flex: 1, borderWidth: 1, borderColor: "#333", borderRadius: 8, padding: 14, alignItems: "center" }}
              >
                <Text style={{ color: "#555" }}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={saveMonthlyEvent}
                style={{ flex: 1, backgroundColor: "#4444ff", borderRadius: 8, padding: 14, alignItems: "center" }}
              >
                <Text style={{ color: "#fff", fontWeight: "bold" }}>Save</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </KeyboardAvoidingView>
  );
}