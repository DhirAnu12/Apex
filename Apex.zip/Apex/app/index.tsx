import AsyncStorage from "@react-native-async-storage/async-storage";
import * as Clipboard from "expo-clipboard";
import * as ImagePicker from "expo-image-picker";
import { useEffect, useRef, useState } from "react";
import { KeyboardAvoidingView, ScrollView, Text, TextInput, TouchableOpacity, View } from "react-native";
import Markdown from "react-native-markdown-display";

export default function Index() {
  const [journalContext, setJournalContext] = useState("");
  const [userProfile, setUserProfile] = useState("");
  const [memoryContext, setMemoryContext] = useState("");
  const [messages, setMessages] = useState([
    { role: "assistant", content: "Yo. What are we working on today?" }
  ]);
  const [chatId, setChatId] = useState(Date.now().toString());
  const [showHistory, setShowHistory] = useState(false);
  const [chatList, setChatList] = useState<any[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [showMediaMenu, setShowMediaMenu] = useState(false);
  const scrollRef = useRef<ScrollView>(null);

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    const loadJournal = async () => {
      try {
        const stored = await AsyncStorage.getItem("journalEntries");
        if (stored) {
          const entries = JSON.parse(stored);
          const recent = entries.slice(0, 3).map((e: any) => `Date: ${e.date}\nMood: ${e.mood || "not stated"}\nEntry: ${e.text}`).join("\n\n");
          setJournalContext(recent);
        }
        const chats = await AsyncStorage.getItem("chatList");
        if (chats) setChatList(JSON.parse(chats));
      } catch (e) {}
    };
    loadJournal();
  });

  const loadData = async () => {
    try {
      const profile = await AsyncStorage.getItem("userProfile");
      if (profile) setUserProfile(profile);
      const memory = await AsyncStorage.getItem("apexMemory");
      if (memory) setMemoryContext(memory);
    } catch (e) {}
  };

  const updateMemory = async (newFact: string) => {
    try {
      const stored = await AsyncStorage.getItem("apexMemory");
      const existing = stored ? stored + "\n" + newFact : newFact;
      await AsyncStorage.setItem("apexMemory", existing);
      setMemoryContext(existing);
    } catch (e) {}
  };

  const saveChat = async (msgs: any[]) => {
    try {
      const stored = await AsyncStorage.getItem("chatList");
      const list = stored ? JSON.parse(stored) : [];
      const existing = list.findIndex((c: any) => c.id === chatId);
      const lastMsg = msgs[msgs.length - 1];
      const preview = typeof lastMsg?.content === "string" ? lastMsg.content.slice(0, 60) : "Image message";
      const updated = existing >= 0
        ? list.map((c: any) => c.id === chatId ? { ...c, messages: msgs, preview, date: new Date().toLocaleDateString() } : c)
        : [{ id: chatId, messages: msgs, preview, date: new Date().toLocaleDateString() }, ...list];
      setChatList(updated);
      await AsyncStorage.setItem("chatList", JSON.stringify(updated));
    } catch (e) {}
  };

  const startNewChat = () => {
    setChatId(Date.now().toString());
    setMessages([{ role: "assistant", content: "Yo. What are we working on today?" }]);
    setShowHistory(false);
  };

  const loadChat = (chat: any) => {
    setChatId(chat.id);
    setMessages(chat.messages);
    setShowHistory(false);
  };

  const pickImage = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      base64: true,
      quality: 0.3
    });
    if (!result.canceled) {
      setSelectedImage(result.assets[0].base64 || null);
    }
  };

  const takePhoto = async () => {
    const permission = await ImagePicker.requestCameraPermissionsAsync();
    if (!permission.granted) return;
    const result = await ImagePicker.launchCameraAsync({
      base64: true,
      quality: 0.3
    });
    if (!result.canceled) {
      setSelectedImage(result.assets[0].base64 || null);
    }
  };

  const sendMessage = async () => {
    if (!input.trim() && !selectedImage) return;
    const userMessage = input;
    const imageToSend = selectedImage;

    const displayMessage = {
      role: "user",
      content: userMessage || "📷 Image sent"
    };

    setMessages(prev => [...prev, displayMessage]);
    setInput("");
    setSelectedImage(null);
    setShowMediaMenu(false);
    setLoading(true);

    try {
      const response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": "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",
          "anthropic-version": "2023-06-01",
          "anthropic-dangerous-direct-browser-access": "true"
        },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 2048,
          system: `You are the user's personal AI assistant and Mentor. You evaluate the person's decisions and help the user become the best version of themselves. You know exactly who they are, where they're going, and what they need to do to get there. You are direct, sharp, and efficient. You do not write essays. You do not end with questions. You do not moralize or lecture.

Your response style:
- Keep responses short and direct unless they ask for a full plan or blueprint
- If they ask how to do something, give them a clear step by step blueprint
- If they send an image, analyze it thoroughly and give a clear step by step breakdown or solution
- If they ask you to write code, write clean and complete code with clear explanations. Format it properly using markdown code blocks with the language specified
- If they tell you they did something off track, acknowledge it, tell them the impact in one line and exactly how to adjust or make up for it. Move on
- Never end with a question unless it is to clarify something
- Never give a speech
- You are a sharp mentor but you talk like a friend and an assistant who respects the user's time and actually wants the user to win

Here is everything you know about this person:\n\n${userProfile}\n\n${journalContext ? `Their recent journal entries:\n\n${journalContext}` : ""}\n\n${memoryContext ? `Things you have learned and remembered about this person over time:\n\n${memoryContext}` : ""}\n\nIf the user asks you to add, set, or schedule something to their calendar or weekly schedule, you MUST include this exact JSON on the last line, no exceptions: CALENDAR_EVENT:{"title":"event name","time":"time string","day":"Monday"}. Always do this immediately when asked, do not ask for confirmation.\n\nIf you learn something important and new about the user that should be remembered long term, add this on the last line: REMEMBER:the fact to remember. Only use this for truly important facts like new goals, major life changes, or key personal details they share.`,
          messages: [...messages, {
            role: "user",
            content: imageToSend
              ? [
                  { type: "image", source: { type: "base64", media_type: "image/jpeg", data: imageToSend } },
                  { type: "text", text: userMessage || "Analyze this image and give me a step by step breakdown." }
                ]
              : userMessage
          }]
        })
      });

      const data = await response.json();

      if (!response.ok || !data.content || !data.content[0]) {
        const errorMsg = data.error?.message || JSON.stringify(data);
        setMessages(prev => [...prev, { role: "assistant", content: `Error: ${errorMsg}` }]);
        setLoading(false);
        return;
      }

      const aiReply = data.content[0].text;

      const calendarMatch = aiReply.match(/CALENDAR_EVENT:\s*(\{[\s\S]*?\})/);
      if (calendarMatch) {
        try {
          const newEvent = JSON.parse(calendarMatch[1]);
          newEvent.id = Date.now().toString();
          const stored = await AsyncStorage.getItem("calendarEvents");
          const existing = stored ? JSON.parse(stored) : [];
          const updated = [...existing, newEvent];
          await AsyncStorage.setItem("calendarEvents", JSON.stringify(updated));
        } catch (e) {}
      }

      const memoryMatch = aiReply.match(/REMEMBER:(.*)/);
      if (memoryMatch) {
        await updateMemory(memoryMatch[1].trim());
      }

      const finalReply = aiReply
        .replace(/CALENDAR_EVENT:\s*\{[\s\S]*?\}/, "")
        .replace(/REMEMBER:.*/, "")
        .trim();

      const updatedMessages = [...messages, displayMessage, { role: "assistant", content: finalReply }];
      setMessages(prev => [...prev, { role: "assistant", content: finalReply }]);
      setLoading(false);
      await saveChat(updatedMessages);
    } catch (error) {
      setLoading(false);
      setMessages(prev => [...prev, { role: "assistant", content: `Error: ${error}` }]);
    }
  };

  const markdownRules = {
    fence: (node: any) => (
      <View key={node.key} style={{ backgroundColor: "#0d1117", borderRadius: 8, marginVertical: 8, borderWidth: 1, borderColor: "#333", overflow: "hidden" }}>
        <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingHorizontal: 12, paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: "#333", backgroundColor: "#161b22" }}>
          <Text style={{ color: "#555", fontSize: 11 }}>{node.sourceInfo || "code"}</Text>
          <TouchableOpacity onPress={() => Clipboard.setStringAsync(node.content)}>
            <Text style={{ color: "#4444ff", fontSize: 12 }}>Copy</Text>
          </TouchableOpacity>
        </View>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          <Text style={{ color: "#e6edf3", fontSize: 13, padding: 12, fontFamily: "monospace", lineHeight: 20 }}>{node.content}</Text>
        </ScrollView>
      </View>
    ),
    code_block: (node: any) => (
      <View key={node.key} style={{ backgroundColor: "#0d1117", borderRadius: 8, marginVertical: 8, borderWidth: 1, borderColor: "#333", overflow: "hidden" }}>
        <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingHorizontal: 12, paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: "#333", backgroundColor: "#161b22" }}>
          <Text style={{ color: "#555", fontSize: 11 }}>code</Text>
          <TouchableOpacity onPress={() => Clipboard.setStringAsync(node.content)}>
            <Text style={{ color: "#4444ff", fontSize: 12 }}>Copy</Text>
          </TouchableOpacity>
        </View>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          <Text style={{ color: "#e6edf3", fontSize: 13, padding: 12, fontFamily: "monospace", lineHeight: 20 }}>{node.content}</Text>
        </ScrollView>
      </View>
    )
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1, backgroundColor: "#0a0a0a" }} behavior="padding" keyboardVerticalOffset={0}>
      <View style={{ padding: 20, paddingTop: 60, borderBottomColor: "#222", borderBottomWidth: 1, flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}>
        <Text style={{ color: "#fff", fontSize: 18, fontWeight: "bold" }}>Your AI Companion</Text>
        <View style={{ flexDirection: "row", gap: 12 }}>
          <TouchableOpacity onPress={() => setShowHistory(!showHistory)}>
            <Text style={{ color: "#4444ff", fontSize: 13 }}>History</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={startNewChat}>
            <Text style={{ color: "#4444ff", fontSize: 13 }}>+ New</Text>
          </TouchableOpacity>
        </View>
      </View>

      {showHistory && (
        <View style={{ position: "absolute", top: 110, left: 0, right: 0, bottom: 0, backgroundColor: "#0a0a0a", zIndex: 10, padding: 20 }}>
          <Text style={{ color: "#555", fontSize: 13, marginBottom: 16 }}>PAST CONVERSATIONS</Text>
          <ScrollView>
            {chatList.length === 0 && (
              <Text style={{ color: "#555", fontSize: 14 }}>No saved chats yet.</Text>
            )}
            {chatList.map((chat) => (
              <TouchableOpacity
                key={chat.id}
                onPress={() => loadChat(chat)}
                style={{
                  backgroundColor: chat.id === chatId ? "#1a1a2e" : "#111",
                  borderRadius: 12,
                  padding: 14,
                  marginBottom: 10,
                  borderWidth: 1,
                  borderColor: chat.id === chatId ? "#4444ff" : "#222"
                }}
              >
                <Text style={{ color: "#555", fontSize: 11, marginBottom: 4 }}>{chat.date}</Text>
                <Text style={{ color: "#fff", fontSize: 14 }} numberOfLines={2}>{chat.preview}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>
      )}

      <ScrollView
        ref={scrollRef}
        style={{ flex: 1, padding: 20 }}
        onContentSizeChange={() => scrollRef.current?.scrollToEnd({ animated: true })}
      >
        {messages.map((msg, index) => (
          <View key={index} style={{
            alignSelf: msg.role === "user" ? "flex-end" : "flex-start",
            backgroundColor: msg.role === "user" ? "#1a1a2e" : "#111",
            padding: 12,
            borderRadius: 12,
            marginBottom: 12,
            maxWidth: "80%",
            borderWidth: 1,
            borderColor: msg.role === "user" ? "#4444ff" : "#222"
          }}>
            {msg.role === "assistant" ? (
              <Markdown
                style={{
                  body: { color: "#fff", fontSize: 15 },
                  strong: { color: "#fff", fontWeight: "bold" },
                  bullet_list: { color: "#fff" },
                  ordered_list: { color: "#fff" },
                  code_inline: { backgroundColor: "#222", color: "#4af", borderRadius: 4, paddingHorizontal: 4 },
                  code_block: { backgroundColor: "#1a1a1a", color: "#4af", borderRadius: 8, padding: 12 },
                  heading1: { color: "#fff", fontSize: 18, fontWeight: "bold", marginBottom: 4 },
                  heading2: { color: "#fff", fontSize: 16, fontWeight: "bold", marginBottom: 4 },
                  heading3: { color: "#fff", fontSize: 15, fontWeight: "bold" },
                }}
                rules={markdownRules}
              >
                {msg.content}
              </Markdown>
            ) : (
              <Text style={{ color: "#fff", fontSize: 15 }}>{msg.content}</Text>
            )}
          </View>
        ))}
        {loading && (
          <View style={{
            alignSelf: "flex-start",
            backgroundColor: "#111",
            padding: 12,
            borderRadius: 12,
            marginBottom: 12,
            borderWidth: 1,
            borderColor: "#222"
          }}>
            <Text style={{ color: "#555", fontSize: 15 }}>Thinking...</Text>
          </View>
        )}
      </ScrollView>

      <View style={{ borderTopColor: "#222", borderTopWidth: 1 }}>
        {showMediaMenu && (
          <View style={{ flexDirection: "row", padding: 12, paddingBottom: 0, gap: 10 }}>
            <TouchableOpacity
              onPress={() => { takePhoto(); setShowMediaMenu(false); }}
              style={{ flex: 1, backgroundColor: "#111", borderRadius: 12, padding: 14, alignItems: "center", borderWidth: 1, borderColor: "#333" }}
            >
              <Text style={{ color: "#fff", fontSize: 13 }}>📷 Camera</Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => { pickImage(); setShowMediaMenu(false); }}
              style={{ flex: 1, backgroundColor: "#111", borderRadius: 12, padding: 14, alignItems: "center", borderWidth: 1, borderColor: "#333" }}
            >
              <Text style={{ color: "#fff", fontSize: 13 }}>🖼️ Gallery</Text>
            </TouchableOpacity>
          </View>
        )}

        {selectedImage && (
          <View style={{ padding: 12, paddingBottom: 0 }}>
            <View style={{ flexDirection: "row", alignItems: "center", backgroundColor: "#111", borderRadius: 10, padding: 10, borderWidth: 1, borderColor: "#4444ff" }}>
              <Text style={{ color: "#4444ff", fontSize: 13, flex: 1 }}>📷 Image attached</Text>
              <TouchableOpacity onPress={() => setSelectedImage(null)}>
                <Text style={{ color: "#ff4444", fontSize: 16 }}>×</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}

        <View style={{ flexDirection: "row", padding: 12, alignItems: "flex-end", gap: 8 }}>
          <TouchableOpacity
            onPress={() => setShowMediaMenu(!showMediaMenu)}
            style={{
              width: 36,
              height: 36,
              borderRadius: 18,
              backgroundColor: "#222",
              justifyContent: "center",
              alignItems: "center"
            }}
          >
            <Text style={{ color: "#fff", fontSize: 22, lineHeight: 26 }}>+</Text>
          </TouchableOpacity>
          <TextInput
            style={{
              flex: 1,
              backgroundColor: "#111",
              color: "#fff",
              borderRadius: 12,
              paddingHorizontal: 16,
              paddingVertical: 10,
              borderWidth: 1,
              borderColor: "#333",
              fontSize: 15,
              maxHeight: 120
            }}
            value={input}
            onChangeText={setInput}
            placeholder="Type something..."
            placeholderTextColor="#555"
            multiline
          />
          <TouchableOpacity
            onPress={sendMessage}
            style={{
              backgroundColor: "#4444ff",
              borderRadius: 12,
              paddingHorizontal: 18,
              paddingVertical: 10,
              justifyContent: "center"
            }}
          >
            <Text style={{ color: "#fff", fontWeight: "bold" }}>Send</Text>
          </TouchableOpacity>
        </View>
      </View>
    </KeyboardAvoidingView>
  );
}