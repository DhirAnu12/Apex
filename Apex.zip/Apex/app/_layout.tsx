import AsyncStorage from "@react-native-async-storage/async-storage";
import * as Notifications from "expo-notifications";
import { Tabs } from "expo-router";
import { useEffect, useState } from "react";
import { Animated, Image, KeyboardAvoidingView, Modal, Text, TextInput, TouchableOpacity, View } from "react-native";

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowBanner: true,
    shouldShowList: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
  }),
});

const QUESTIONS = [
  "What's the purpose of this chapter of your life?",
  "If you could create the most amazing life you could imagine, what exactly would it be?",
  "How would it feel if you hit that age and none of this ever happened to you?",
  "How is your life right now and are you happy with it?",
  "What are your short term and long term goals?",
  "What is your biggest weakness or habit that is holding you back right now?",
  "What does your ideal daily routine look like when you've made it?",
  "What is your current daily schedule? Include your classes, work, and any fixed commitments with their times and days."
];

function SplashScreen({ onFinish }: { onFinish: () => void }) {
  const opacity = new Animated.Value(0);
  const scale = new Animated.Value(0.8);

  useEffect(() => {
    Animated.parallel([
      Animated.timing(opacity, { toValue: 1, duration: 800, useNativeDriver: true }),
      Animated.spring(scale, { toValue: 1, tension: 50, friction: 7, useNativeDriver: true })
    ]).start(() => {
      setTimeout(() => {
        Animated.timing(opacity, { toValue: 0, duration: 500, useNativeDriver: true }).start(onFinish);
      }, 1500);
    });
  }, []);

  return (
    <View style={{ flex: 1, backgroundColor: "#0a0a0a", justifyContent: "center", alignItems: "center" }}>
      <Animated.View style={{ opacity, transform: [{ scale }], alignItems: "center" }}>
        <Image
          source={require("../assets/images/icon.png")}
          style={{ width: 100, height: 100, borderRadius: 20, marginBottom: 20 }}
        />
        <Text style={{ color: "#fff", fontSize: 32, fontWeight: "bold", letterSpacing: 4 }}>APEX</Text>
        <Text style={{ color: "#555", fontSize: 13, marginTop: 8, letterSpacing: 2 }}>BUILD THE BEST VERSION OF YOU</Text>
      </Animated.View>
    </View>
  );
}

export default function RootLayout() {
  const [showSplash, setShowSplash] = useState(true);
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [ready, setReady] = useState(false);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<string[]>([]);
  const [currentAnswer, setCurrentAnswer] = useState("");

  useEffect(() => {
    requestPermissions();
    checkOnboarding();
  }, []);

  const requestPermissions = async () => {
    await Notifications.requestPermissionsAsync();
  };

  const checkOnboarding = async () => {
    try {
      const profile = await AsyncStorage.getItem("userProfile");
      if (!profile) setShowOnboarding(true);
    } catch (e) {
      setShowOnboarding(true);
    }
    setReady(true);
  };

  const handleAnswer = async () => {
    if (!currentAnswer.trim()) return;
    const newAnswers = [...answers, currentAnswer];
    setAnswers(newAnswers);
    setCurrentAnswer("");

    if (currentQuestion < QUESTIONS.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      const profile = QUESTIONS.map((q, i) => `${q}\n${newAnswers[i]}`).join("\n\n");
      try {
        await AsyncStorage.setItem("userProfile", profile);
      } catch (e) {}
      setShowOnboarding(false);
    }
  };

  if (showSplash || !ready) {
    return <SplashScreen onFinish={() => setShowSplash(false)} />;
  }

  return (
    <>
      <Tabs
        screenOptions={{
          tabBarStyle: { backgroundColor: "#0a0a0a", borderTopColor: "#222" },
          tabBarActiveTintColor: "#4444ff",
          tabBarInactiveTintColor: "#555",
          headerShown: false
        }}
      >
        <Tabs.Screen name="index" options={{ title: "Chat" }} />
        <Tabs.Screen name="journal" options={{ title: "Journal" }} />
        <Tabs.Screen name="routine" options={{ title: "Routine" }} />
        <Tabs.Screen name="calendar" options={{ title: "Calendar" }} />
        <Tabs.Screen name="performance" options={{ title: "Performance" }} />
      </Tabs>

      <Modal visible={showOnboarding} animationType="fade">
        <KeyboardAvoidingView style={{ flex: 1, backgroundColor: "#0a0a0a" }} behavior="padding" keyboardVerticalOffset={0}>
          <View style={{ flex: 1, padding: 24, justifyContent: "center" }}>
            <Text style={{ color: "#4444ff", fontSize: 13, marginBottom: 8, letterSpacing: 1 }}>
              QUESTION {currentQuestion + 1} OF {QUESTIONS.length}
            </Text>
            <View style={{ height: 4, backgroundColor: "#222", borderRadius: 2, marginBottom: 32 }}>
              <View style={{
                height: 4,
                backgroundColor: "#4444ff",
                borderRadius: 2,
                width: `${((currentQuestion + 1) / QUESTIONS.length) * 100}%` as any
              }} />
            </View>
            <Text style={{ color: "#fff", fontSize: 22, fontWeight: "bold", marginBottom: 32, lineHeight: 30 }}>
              {QUESTIONS[currentQuestion]}
            </Text>
            <TextInput
              style={{
                backgroundColor: "#111",
                color: "#fff",
                borderRadius: 12,
                padding: 16,
                fontSize: 15,
                borderWidth: 1,
                borderColor: "#333",
                minHeight: 120,
                textAlignVertical: "top",
                marginBottom: 20
              }}
              value={currentAnswer}
              onChangeText={setCurrentAnswer}
              placeholder="Be honest. No one is watching."
              placeholderTextColor="#555"
              multiline
            />
            <TouchableOpacity
              onPress={handleAnswer}
              style={{
                backgroundColor: "#4444ff",
                borderRadius: 12,
                padding: 16,
                alignItems: "center"
              }}
            >
              <Text style={{ color: "#fff", fontWeight: "bold", fontSize: 16 }}>
                {currentQuestion < QUESTIONS.length - 1 ? "Next" : "Let's Go"}
              </Text>
            </TouchableOpacity>
          </View>
        </KeyboardAvoidingView>
      </Modal>
    </>
  );
}